package negocio;


public interface GestionServicioRecargaLocal {
	public boolean aprobarRecarga(String cedula, String numeroTelefono, double monto );
	
}
