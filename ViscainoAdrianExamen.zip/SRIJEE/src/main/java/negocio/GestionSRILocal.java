package negocio;


public interface GestionSRILocal {
	public String aprobarFactura(String cedula, int numFactura, double valorF );
	
}
