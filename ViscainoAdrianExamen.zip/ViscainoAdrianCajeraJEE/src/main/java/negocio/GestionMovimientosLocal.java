package negocio;

public interface GestionMovimientosLocal {
	public void Transaccion(String numCuenta, int numeroFactura, int clave, int valor);

}
