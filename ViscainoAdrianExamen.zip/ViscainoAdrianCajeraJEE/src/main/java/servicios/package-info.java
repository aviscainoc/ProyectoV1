@javax.xml.bind.annotation.XmlSchema(namespace = "http://servicios/")
package servicios;
