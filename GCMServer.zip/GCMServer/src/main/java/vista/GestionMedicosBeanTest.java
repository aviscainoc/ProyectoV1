package vista;

import static org.junit.Assert.*;

import org.junit.Test;

public class GestionMedicosBeanTest {

	@Test
	public void testGetGl() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetGl() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetUs_codigo() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetUs_codigo() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetUs_nombre() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetUs_nombre() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetUs_fechaNacimiento() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetUs_fechaNacimiento() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetUs_nickname() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetUs_nickname() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetUs_password() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetUs_password() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetMedicos() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetMedicos() {
		fail("Not yet implemented");
	}

	@Test
	public void testGuardarUsuarios() {
		fail("Not yet implemented");
	}

	@Test
	public void testRecuperarMedicos() {
		fail("Not yet implemented");
	}

	@Test
	public void testEliminar() {
		fail("Not yet implemented");
	}

	@Test
	public void testUpdate() {
		fail("Not yet implemented");
	}

	@Test
	public void testLogin() {
		fail("Not yet implemented");
	}

}
